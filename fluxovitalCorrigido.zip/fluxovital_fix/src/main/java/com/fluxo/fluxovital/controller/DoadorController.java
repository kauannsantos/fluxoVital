package com.fluxo.fluxovital.controller;

import com.fluxo.fluxovital.model.Doador;
import com.fluxo.fluxovital.model.DoadorSangue;
import com.fluxo.fluxovital.model.DoadoraLeite;
import com.fluxo.fluxovital.repository.DoadorRepository;
import com.fluxo.fluxovital.repository.DoadorSangueRepository;
import com.fluxo.fluxovital.repository.DoadoraLeiteRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.Year;
import java.util.List;
import java.util.Optional;

@Controller
public class DoadorController {

    private final DoadorRepository         doadorRepository;
    private final DoadorSangueRepository   doadorSangueRepository;
    private final DoadoraLeiteRepository   doadoraLeiteRepository;
    private final PasswordEncoder          passwordEncoder;

    public DoadorController(DoadorRepository doadorRepository,
                            DoadorSangueRepository doadorSangueRepository,
                            DoadoraLeiteRepository doadoraLeiteRepository,
                            PasswordEncoder passwordEncoder) {
        this.doadorRepository       = doadorRepository;
        this.doadorSangueRepository = doadorSangueRepository;
        this.doadoraLeiteRepository = doadoraLeiteRepository;
        this.passwordEncoder        = passwordEncoder;
    }

    // ─── CADASTRO ─────────────────────────────────────────────────────────────

    @GetMapping("/doador/cadastro")
    public String exibirCadastro(HttpSession session, Model model) {
        if (session.getAttribute("tipo_doacao") == null)
            session.setAttribute("tipo_doacao", "sangue");
        model.addAttribute("tipoDoacao", session.getAttribute("tipo_doacao"));
        model.addAttribute("anoAtual", Year.now().getValue());
        return "doador/cadastro/cadastro_doador";
    }

    @PostMapping("/doador/cadastro")
    public String processarCadastro(
            @RequestParam String nome,
            @RequestParam String email,
            @RequestParam String telefone,
            @RequestParam String senha,
            @RequestParam("confirma_senha") String confirmaSenha,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String tipoDoador = (String) session.getAttribute("tipo_doacao");
        if (tipoDoador == null || !List.of("sangue","medula","leite").contains(tipoDoador))
            tipoDoador = "sangue";

        if (nome.isBlank() || email.isBlank() || telefone.isBlank() || senha.isBlank()) {
            redirectAttributes.addFlashAttribute("erro", "Preencha todos os campos.");
            return "redirect:/doador/cadastro";
        }
        if (!senha.equals(confirmaSenha)) {
            redirectAttributes.addFlashAttribute("erro", "As senhas nao coincidem.");
            return "redirect:/doador/cadastro";
        }

        Optional<Doador> existente = doadorRepository.findByEmail(email.trim());
        if (existente.isPresent()) {
            Doador d = existente.get();
            if (passwordEncoder.matches(senha, d.getSenha())) {
                preencherSessao(session, d);
                return "redirect:/doador/home";
            }
            redirectAttributes.addFlashAttribute("erro", "E-mail ja cadastrado com senha diferente.");
            return "redirect:/doador/cadastro";
        }

        Doador novo = new Doador();
        novo.setNome(nome.trim());
        novo.setEmail(email.trim());
        novo.setTelefone(telefone.trim());
        novo.setSenha(passwordEncoder.encode(senha));
        novo.setTipoDoador(tipoDoador);
        doadorRepository.save(novo);

        preencherSessao(session, novo);
        redirectAttributes.addFlashAttribute("sucesso",
            "Cadastro realizado com sucesso! Agora preencha seu formulario de doacao.");
        return "redirect:/doador/home";
    }

    // ─── HOME ─────────────────────────────────────────────────────────────────

    @GetMapping("/doador/home")
    public String homeDoador(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null)
            return "redirect:/doador/cadastro";
        model.addAttribute("nome",      session.getAttribute("doador_nome"));
        model.addAttribute("tipoDoador", session.getAttribute("tipo_doacao"));

        Long id = (Long) session.getAttribute("doador_id");
        model.addAttribute("formulariosSangue",
            doadorSangueRepository.findByDoadorIdOrderByCriadoEmDesc(id));
        model.addAttribute("formulariosLeite",
            doadoraLeiteRepository.findByDoadorIdOrderByCriadoEmDesc(id));
        return "doador/home";
    }

    // ─── FORMULÁRIO DE SANGUE ─────────────────────────────────────────────────

    @GetMapping("/doador/sangue/form")
    public String formSangue(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        model.addAttribute("doadorNome", session.getAttribute("doador_nome"));
        model.addAttribute("anoAtual", Year.now().getValue());
        return "doador/sangue/form";
    }

    @PostMapping("/doador/sangue/form")
    public String salvarSangue(
            @RequestParam(required = false) String nome,
            @RequestParam(required = false) String cpf,
            @RequestParam(required = false) String rg,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate nascimento,
            @RequestParam(required = false) String sexo,
            @RequestParam(required = false) Double peso,
            @RequestParam(required = false) Double altura,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String telefone,
            @RequestParam(required = false) String endereco,
            @RequestParam(required = false) String tipo_sanguineo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate ultima_doacao,
            @RequestParam(required = false) String inab_hiv,
            @RequestParam(required = false) String inab_htlv,
            @RequestParam(required = false) String inab_hepatite,
            @RequestParam(required = false) String inab_sifilis,
            @RequestParam(required = false) String inab_chagas,
            @RequestParam(required = false) String inab_cancer,
            @RequestParam(required = false) String inab_epilepsia,
            @RequestParam(required = false) String aval_medicamento,
            @RequestParam(required = false) String aval_alcool,
            @RequestParam(required = false) String aval_cigarro,
            @RequestParam(required = false) String aval_vacina,
            @RequestParam(required = false) String aval_cirurgia,
            @RequestParam(required = false) String aval_gravidez,
            @RequestParam(required = false) String aval_tatuagem,
            @RequestParam(required = false) String aval_febre,
            @RequestParam(required = false) String aval_diabetes,
            @RequestParam(required = false) String aval_hipertensao,
            @RequestParam(required = false) String historico_doacao,
            @RequestParam(required = false) String observacoes,
            @RequestParam(required = false) String unidade,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data_agendamento,
            @RequestParam(required = false) String turno,
            @RequestParam(required = false) String como_soube,
            @RequestParam(required = false) String consentimento,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";

        Long doadorId = (Long) session.getAttribute("doador_id");
        Doador doador = doadorRepository.findById(doadorId).orElse(null);

        DoadorSangue ds = new DoadorSangue();
        ds.setDoador(doador);
        ds.setNome(nome != null ? nome.trim() : (String) session.getAttribute("doador_nome"));
        ds.setCpf(cpf != null ? cpf.replaceAll("\\D","") : null);
        ds.setRg(rg);
        ds.setNascimento(nascimento);
        if (sexo != null && !sexo.isBlank()) {
            try {
                ds.setSexo(DoadorSangue.Sexo.valueOf(sexo.trim().toLowerCase()));
            } catch (IllegalArgumentException e) {
                // valor inválido recebido: logar para debug
                System.err.println("Valor inválido para sexo: '" + sexo + "'");
                ds.setSexo(null); // ou defina um valor padrão
            }
        }
        ds.setPeso(peso);
        ds.setAltura(altura);
        ds.setEmail(email);
        ds.setTelefone(telefone);
        ds.setEndereco(endereco);
        ds.setTipoSanguineo(tipo_sanguineo);
        ds.setUltimaDoacao(ultima_doacao);

        ds.setInabHiv("1".equals(inab_hiv));
        ds.setInabHtlv("1".equals(inab_htlv));
        ds.setInabHepatite("1".equals(inab_hepatite));
        ds.setInabSifilis("1".equals(inab_sifilis));
        ds.setInabChagas("1".equals(inab_chagas));
        ds.setInabCancer("1".equals(inab_cancer));
        ds.setInabEpilepsia("1".equals(inab_epilepsia));
        ds.setCondMedicamento("1".equals(aval_medicamento));
        ds.setAvalAlcool("1".equals(aval_alcool));
        ds.setAvalCigarro("1".equals(aval_cigarro));
        ds.setAvalVacina("1".equals(aval_vacina));
        ds.setCondCirurgia("1".equals(aval_cirurgia));
        ds.setAvalGravidez("1".equals(aval_gravidez));
        ds.setCondTatuagem("1".equals(aval_tatuagem));
        ds.setAvalFebre("1".equals(aval_febre));
        ds.setAvalDiabetes("1".equals(aval_diabetes));
        ds.setAvalHipertensao("1".equals(aval_hipertensao));

        if (historico_doacao != null && !historico_doacao.isBlank()) {
            try { ds.setHistoricoDoacao(DoadorSangue.HistoricoDoacao.valueOf(historico_doacao)); }
            catch (Exception ignored) {}
        }
        ds.setObservacoes(observacoes);
        ds.setUnidade(unidade);
        ds.setDataAgendamento(data_agendamento);
        if (turno != null && !turno.isBlank()) {
            try { ds.setTurno(DoadorSangue.Turno.valueOf(turno)); } catch (Exception ignored) {}
        }
        ds.setComoSoube(como_soube);
        ds.setConsentimento("1".equals(consentimento));

        doadorSangueRepository.save(ds);

        redirectAttributes.addFlashAttribute("sucesso",
            "Formulario de doacao de sangue enviado com sucesso! Seu cadastro foi registrado e a instituicao entrara em contato em breve.");
        return "redirect:/doador/home";
    }

    // ─── FORMULÁRIO DE MEDULA ─────────────────────────────────────────────────

    @GetMapping("/doador/medula/form")
    public String formMedula(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        model.addAttribute("doadorNome", session.getAttribute("doador_nome"));
        model.addAttribute("anoAtual", Year.now().getValue());
        return "doador/medula/form";
    }

    @PostMapping("/doador/medula/form")
    public String salvarMedula(HttpSession session, RedirectAttributes redirectAttributes) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        redirectAttributes.addFlashAttribute("sucesso",
            "Cadastro de doador de medula enviado! Aguarde contato para tipagem HLA.");
        return "redirect:/doador/home";
    }

    // ─── FORMULÁRIO DE LEITE ──────────────────────────────────────────────────

    @GetMapping("/doador/leite/form")
    public String formLeite(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        model.addAttribute("doadorNome", session.getAttribute("doador_nome"));
        model.addAttribute("anoAtual", Year.now().getValue());
        return "doador/leite/form";
    }

    @PostMapping("/doador/leite/form")
    public String salvarLeite(
            @RequestParam(required = false) String nome,
            @RequestParam(required = false) String cpf,
            @RequestParam(required = false) String rg,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate nascimento,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String telefone,
            @RequestParam(required = false) String endereco,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data_parto,
            @RequestParam(required = false) String tipo_parto,
            @RequestParam(required = false) String idade_gestacional,
            @RequestParam(required = false) String num_filhos_amamentando,
            @RequestParam(required = false) String amamentacao_exclusiva,
            @RequestParam(required = false) String producao_estimada,
            @RequestParam(required = false) String inab_hiv,
            @RequestParam(required = false) String inab_htlv,
            @RequestParam(required = false) String inab_hepatite,
            @RequestParam(required = false) String inab_sifilis,
            @RequestParam(required = false) String inab_chagas,
            @RequestParam(required = false) String inab_mastite,
            @RequestParam(required = false) String inab_candidiase_mam,
            @RequestParam(required = false) String inab_radio,
            @RequestParam(required = false) String aval_medicamento,
            @RequestParam(required = false) String aval_alcool,
            @RequestParam(required = false) String aval_cigarro,
            @RequestParam(required = false) String aval_vacina,
            @RequestParam(required = false) String aval_procedimento,
            @RequestParam(required = false) String aval_silicone,
            @RequestParam(required = false) String aval_diabetes,
            @RequestParam(required = false) String aval_hipertensao,
            @RequestParam(required = false) String historico_doacao,
            @RequestParam(required = false) String modalidade_coleta,
            @RequestParam(required = false) String observacoes,
            @RequestParam(required = false) String unidade,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data_agendamento,
            @RequestParam(required = false) String turno,
            @RequestParam(required = false) String como_soube,
            @RequestParam(required = false) String consentimento,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";

        Long doadorId = (Long) session.getAttribute("doador_id");
        Doador doador = doadorRepository.findById(doadorId).orElse(null);

        DoadoraLeite dl = new DoadoraLeite();
        dl.setDoador(doador);
        dl.setNome(nome != null ? nome.trim() : (String) session.getAttribute("doador_nome"));
        dl.setCpf(cpf != null ? cpf.replaceAll("\\D","") : null);
        dl.setRg(rg);
        dl.setNascimento(nascimento);
        dl.setEmail(email);
        dl.setTelefone(telefone);
        dl.setEndereco(endereco);
        dl.setDataParto(data_parto);
        if (tipo_parto != null && !tipo_parto.isBlank()) {
            try { dl.setTipoParto(DoadoraLeite.TipoParto.valueOf(tipo_parto)); } catch (Exception ignored) {}
        }
        if (idade_gestacional != null && !idade_gestacional.isBlank()) {
            try { dl.setIdadeGestacional(DoadoraLeite.IdadeGestacional.valueOf(idade_gestacional)); } catch (Exception ignored) {}
        }
        dl.setNumFilhosAmamentando(num_filhos_amamentando);
        if (amamentacao_exclusiva != null && !amamentacao_exclusiva.isBlank()) {
            try { dl.setAmamentacaoExclusiva(DoadoraLeite.AmamentacaoExclusiva.valueOf(amamentacao_exclusiva)); } catch (Exception ignored) {}
        }
        dl.setProducaoEstimada(producao_estimada);
        dl.setInabHiv("1".equals(inab_hiv));
        dl.setInabHtlv("1".equals(inab_htlv));
        dl.setInabHepatite("1".equals(inab_hepatite));
        dl.setInabSifilis("1".equals(inab_sifilis));
        dl.setInabChagas("1".equals(inab_chagas));
        dl.setInabMastite("1".equals(inab_mastite));
        dl.setInabCandidiaseMam("1".equals(inab_candidiase_mam));
        dl.setInabRadio("1".equals(inab_radio));
        dl.setAvalMedicamento("1".equals(aval_medicamento));
        dl.setAvalAlcool("1".equals(aval_alcool));
        dl.setAvalCigarro("1".equals(aval_cigarro));
        dl.setAvalVacina("1".equals(aval_vacina));
        dl.setAvalProcedimento("1".equals(aval_procedimento));
        dl.setAvalSilicone("1".equals(aval_silicone));
        dl.setAvalDiabetes("1".equals(aval_diabetes));
        dl.setAvalHipertensao("1".equals(aval_hipertensao));
        if (historico_doacao != null && !historico_doacao.isBlank()) {
            try { dl.setHistoricoDoacao(DoadoraLeite.HistoricoDoacaoLeite.valueOf(historico_doacao)); } catch (Exception ignored) {}
        }
        if (modalidade_coleta != null && !modalidade_coleta.isBlank()) {
            try { dl.setModalidadeColeta(DoadoraLeite.ModalidadeColeta.valueOf(modalidade_coleta)); } catch (Exception ignored) {}
        }
        dl.setObservacoes(observacoes);
        dl.setUnidade(unidade);
        dl.setDataAgendamento(data_agendamento);
        if (turno != null && !turno.isBlank()) {
            try { dl.setTurno(DoadoraLeite.TurnoLeite.valueOf(turno)); } catch (Exception ignored) {}
        }
        dl.setComoSoube(como_soube);
        dl.setConsentimento("1".equals(consentimento));

        doadoraLeiteRepository.save(dl);

        redirectAttributes.addFlashAttribute("sucesso",
            "Cadastro de doadora de leite enviado com sucesso! Seu formulario foi registrado e a instituicao entrara em contato em breve.");
        return "redirect:/doador/home";
    }

    // ─── LOGOUT ───────────────────────────────────────────────────────────────

    @GetMapping("/doador/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    // ─── HELPER ───────────────────────────────────────────────────────────────

    private void preencherSessao(HttpSession session, Doador d) {
        session.setAttribute("doador_id",   d.getId());
        session.setAttribute("doador_nome", d.getNome());
        session.setAttribute("tipo_doacao", d.getTipoDoador());
    }
}
