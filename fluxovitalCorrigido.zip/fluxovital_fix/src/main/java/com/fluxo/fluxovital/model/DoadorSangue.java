package com.fluxo.fluxovital.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "doadores_sangue")
public class DoadorSangue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Vínculo com o doador logado
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doador_id")
    private Doador doador;

    // Identificação
    private String nome;
    private String cpf;
    private String rg;
    private LocalDate nascimento;

    @Enumerated(EnumType.STRING)
    private Sexo sexo;

    private Double peso;
    private Double altura;
    private String email;
    private String telefone;
    private String endereco;

    @Column(name = "tipo_sanguineo")
    private String tipoSanguineo;

    @Column(name = "ultima_doacao")
    private LocalDate ultimaDoacao;

    // Triagem — inabilitantes
    @Column(name = "inab_hiv")       private Boolean inabHiv       = false;
    @Column(name = "inab_htlv")      private Boolean inabHtlv      = false;
    @Column(name = "inab_hepatite")  private Boolean inabHepatite  = false;
    @Column(name = "inab_sifilis")   private Boolean inabSifilis   = false;
    @Column(name = "inab_chagas")    private Boolean inabChagas    = false;
    @Column(name = "inab_cancer")    private Boolean inabCancer    = false;
    @Column(name = "inab_epilepsia") private Boolean inabEpilepsia = false;

    // Triagem — avaliação médica
    @Column(name = "cond_vacina")       private Boolean condVacina      = false;
    @Column(name = "cond_tatuagem")     private Boolean condTatuagem    = false;
    @Column(name = "cond_cronica")      private Boolean condCronica     = false;
    @Column(name = "cond_medicamento")  private Boolean condMedicamento = false;
    @Column(name = "cond_infeccao")     private Boolean condInfeccao    = false;
    @Column(name = "cond_cirurgia")     private Boolean condCirurgia    = false;
    @Column(name = "aval_alcool")       private Boolean avalAlcool      = false;
    @Column(name = "aval_cigarro")      private Boolean avalCigarro     = false;
    @Column(name = "aval_vacina")       private Boolean avalVacina      = false;
    @Column(name = "aval_gravidez")     private Boolean avalGravidez    = false;
    @Column(name = "aval_febre")        private Boolean avalFebre       = false;
    @Column(name = "aval_diabetes")     private Boolean avalDiabetes    = false;
    @Column(name = "aval_hipertensao")  private Boolean avalHipertensao = false;

    @Enumerated(EnumType.STRING)
    @Column(name = "historico_doacao")
    private HistoricoDoacao historicoDoacao;

    @Column(length = 600)
    private String observacoes;

    // Agendamento
    private String unidade;

    @Column(name = "data_agendamento")
    private LocalDate dataAgendamento;

    @Enumerated(EnumType.STRING)
    private Turno turno;

    @Column(name = "como_soube")
    private String comoSoube;

    private Boolean consentimento = false;

    // Controle interno
    @Enumerated(EnumType.STRING)
    private StatusTriagem status = StatusTriagem.pendente;

    @Column(name = "criado_em")
    private LocalDateTime criadoEm;

    @PrePersist
    public void prePersist() {
        this.criadoEm = LocalDateTime.now();
        if (this.status == null) this.status = StatusTriagem.pendente;
    }

    public DoadorSangue() {}

    // ─── Enums internos ───────────────────────────────────────────────────────
    public enum Sexo            { masculino, feminino }
    public enum HistoricoDoacao { nunca, sim, regular }
    public enum Turno           { manha, tarde }
    public enum StatusTriagem   { pendente, aprovado, inabilitado }

    // ─── Getters / Setters ────────────────────────────────────────────────────
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Doador getDoador() { return doador; }
    public void setDoador(Doador d) { this.doador = d; }
    public String getNome() { return nome; }
    public void setNome(String v) { this.nome = v; }
    public String getCpf() { return cpf; }
    public void setCpf(String v) { this.cpf = v; }
    public String getRg() { return rg; }
    public void setRg(String v) { this.rg = v; }
    public LocalDate getNascimento() { return nascimento; }
    public void setNascimento(LocalDate v) { this.nascimento = v; }
    public Sexo getSexo() { return sexo; }
    public void setSexo(Sexo v) { this.sexo = v; }
    public Double getPeso() { return peso; }
    public void setPeso(Double v) { this.peso = v; }
    public Double getAltura() { return altura; }
    public void setAltura(Double v) { this.altura = v; }
    public String getEmail() { return email; }
    public void setEmail(String v) { this.email = v; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String v) { this.telefone = v; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String v) { this.endereco = v; }
    public String getTipoSanguineo() { return tipoSanguineo; }
    public void setTipoSanguineo(String v) { this.tipoSanguineo = v; }
    public LocalDate getUltimaDoacao() { return ultimaDoacao; }
    public void setUltimaDoacao(LocalDate v) { this.ultimaDoacao = v; }
    public Boolean getInabHiv() { return inabHiv; }
    public void setInabHiv(Boolean v) { this.inabHiv = v != null && v; }
    public Boolean getInabHtlv() { return inabHtlv; }
    public void setInabHtlv(Boolean v) { this.inabHtlv = v != null && v; }
    public Boolean getInabHepatite() { return inabHepatite; }
    public void setInabHepatite(Boolean v) { this.inabHepatite = v != null && v; }
    public Boolean getInabSifilis() { return inabSifilis; }
    public void setInabSifilis(Boolean v) { this.inabSifilis = v != null && v; }
    public Boolean getInabChagas() { return inabChagas; }
    public void setInabChagas(Boolean v) { this.inabChagas = v != null && v; }
    public Boolean getInabCancer() { return inabCancer; }
    public void setInabCancer(Boolean v) { this.inabCancer = v != null && v; }
    public Boolean getInabEpilepsia() { return inabEpilepsia; }
    public void setInabEpilepsia(Boolean v) { this.inabEpilepsia = v != null && v; }
    public Boolean getCondVacina() { return condVacina; }
    public void setCondVacina(Boolean v) { this.condVacina = v != null && v; }
    public Boolean getCondTatuagem() { return condTatuagem; }
    public void setCondTatuagem(Boolean v) { this.condTatuagem = v != null && v; }
    public Boolean getCondCronica() { return condCronica; }
    public void setCondCronica(Boolean v) { this.condCronica = v != null && v; }
    public Boolean getCondMedicamento() { return condMedicamento; }
    public void setCondMedicamento(Boolean v) { this.condMedicamento = v != null && v; }
    public Boolean getCondInfeccao() { return condInfeccao; }
    public void setCondInfeccao(Boolean v) { this.condInfeccao = v != null && v; }
    public Boolean getCondCirurgia() { return condCirurgia; }
    public void setCondCirurgia(Boolean v) { this.condCirurgia = v != null && v; }
    public Boolean getAvalAlcool() { return avalAlcool; }
    public void setAvalAlcool(Boolean v) { this.avalAlcool = v != null && v; }
    public Boolean getAvalCigarro() { return avalCigarro; }
    public void setAvalCigarro(Boolean v) { this.avalCigarro = v != null && v; }
    public Boolean getAvalVacina() { return avalVacina; }
    public void setAvalVacina(Boolean v) { this.avalVacina = v != null && v; }
    public Boolean getAvalGravidez() { return avalGravidez; }
    public void setAvalGravidez(Boolean v) { this.avalGravidez = v != null && v; }
    public Boolean getAvalFebre() { return avalFebre; }
    public void setAvalFebre(Boolean v) { this.avalFebre = v != null && v; }
    public Boolean getAvalDiabetes() { return avalDiabetes; }
    public void setAvalDiabetes(Boolean v) { this.avalDiabetes = v != null && v; }
    public Boolean getAvalHipertensao() { return avalHipertensao; }
    public void setAvalHipertensao(Boolean v) { this.avalHipertensao = v != null && v; }
    public HistoricoDoacao getHistoricoDoacao() { return historicoDoacao; }
    public void setHistoricoDoacao(HistoricoDoacao v) { this.historicoDoacao = v; }
    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String v) { this.observacoes = v; }
    public String getUnidade() { return unidade; }
    public void setUnidade(String v) { this.unidade = v; }
    public LocalDate getDataAgendamento() { return dataAgendamento; }
    public void setDataAgendamento(LocalDate v) { this.dataAgendamento = v; }
    public Turno getTurno() { return turno; }
    public void setTurno(Turno v) { this.turno = v; }
    public String getComoSoube() { return comoSoube; }
    public void setComoSoube(String v) { this.comoSoube = v; }
    public Boolean getConsentimento() { return consentimento; }
    public void setConsentimento(Boolean v) { this.consentimento = v != null && v; }
    public StatusTriagem getStatus() { return status; }
    public void setStatus(StatusTriagem v) { this.status = v; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime v) { this.criadoEm = v; }
}
