package com.fluxo.fluxovital.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "doadora_leite")
public class DoadoraLeite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doador_id")
    private Doador doador;

    private String nome;
    private String cpf;
    private String rg;
    private LocalDate nascimento;
    private String email;
    private String telefone;
    private String endereco;

    @Column(name = "data_parto")
    private LocalDate dataParto;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_parto")
    private TipoParto tipoParto;

    @Enumerated(EnumType.STRING)
    @Column(name = "idade_gestacional")
    private IdadeGestacional idadeGestacional;

    @Column(name = "num_filhos_amamentando")
    private String numFilhosAmamentando;

    @Enumerated(EnumType.STRING)
    @Column(name = "amamentacao_exclusiva")
    private AmamentacaoExclusiva amamentacaoExclusiva;

    @Column(name = "producao_estimada")
    private String producaoEstimada;

    @Column(name = "inab_hiv")            private Boolean inabHiv           = false;
    @Column(name = "inab_htlv")           private Boolean inabHtlv          = false;
    @Column(name = "inab_hepatite")       private Boolean inabHepatite      = false;
    @Column(name = "inab_sifilis")        private Boolean inabSifilis       = false;
    @Column(name = "inab_chagas")         private Boolean inabChagas        = false;
    @Column(name = "inab_mastite")        private Boolean inabMastite       = false;
    @Column(name = "inab_candidiase_mam") private Boolean inabCandidiaseMam = false;
    @Column(name = "inab_radio")          private Boolean inabRadio         = false;

    @Column(name = "aval_medicamento")    private Boolean avalMedicamento   = false;
    @Column(name = "aval_alcool")         private Boolean avalAlcool        = false;
    @Column(name = "aval_cigarro")        private Boolean avalCigarro       = false;
    @Column(name = "aval_vacina")         private Boolean avalVacina        = false;
    @Column(name = "aval_procedimento")   private Boolean avalProcedimento  = false;
    @Column(name = "aval_silicone")       private Boolean avalSilicone      = false;
    @Column(name = "aval_diabetes")       private Boolean avalDiabetes      = false;
    @Column(name = "aval_hipertensao")    private Boolean avalHipertensao   = false;

    @Enumerated(EnumType.STRING)
    @Column(name = "historico_doacao")
    private HistoricoDoacaoLeite historicoDoacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "modalidade_coleta")
    private ModalidadeColeta modalidadeColeta;

    private String observacoes;

    // String em vez de Enum para evitar problemas de mapeamento
    private String unidade;

    @Column(name = "data_agendamento")
    private LocalDate dataAgendamento;

    @Enumerated(EnumType.STRING)
    private TurnoLeite turno;

    @Column(name = "como_soube")
    private String comoSoube;

    private Boolean consentimento = false;

    @Enumerated(EnumType.STRING)
    private StatusDoadoraLeite status = StatusDoadoraLeite.pendente;

    @Column(name = "criado_em")
    private LocalDateTime criadoEm;

    @Column(name = "atualizado_em")
    private LocalDateTime atualizadoEm;

    @PrePersist
    public void prePersist() {
        this.criadoEm = LocalDateTime.now();
        if (this.status == null) this.status = StatusDoadoraLeite.pendente;
    }

    public DoadoraLeite() {}

    public enum TipoParto            { normal, cesariana }
    public enum IdadeGestacional     { prematuro_extremo, prematuro_moderado, prematuro_tardio, termo }
    public enum AmamentacaoExclusiva { sim, parcial, nao }
    public enum HistoricoDoacaoLeite { nunca, sim, regular }
    public enum ModalidadeColeta     { unidade, domicilio, ambos }
    public enum TurnoLeite           { manha, tarde }
    public enum StatusDoadoraLeite   { pendente, aprovada, inabilitada, em_avaliacao }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Doador getDoador() { return doador; }
    public void setDoador(Doador d) { this.doador = d; }
    public String getNome() { return nome; }
    public void setNome(String v) { this.nome = v; }
    public String getCpf() { return cpf; }
    public void setCpf(String v) { this.cpf = v; }
    public String getRg() { return rg; }
    public void setRg(String v) { this.rg = v; }
    public LocalDate getNascimento() { return nascimento; }
    public void setNascimento(LocalDate v) { this.nascimento = v; }
    public String getEmail() { return email; }
    public void setEmail(String v) { this.email = v; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String v) { this.telefone = v; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String v) { this.endereco = v; }
    public LocalDate getDataParto() { return dataParto; }
    public void setDataParto(LocalDate v) { this.dataParto = v; }
    public TipoParto getTipoParto() { return tipoParto; }
    public void setTipoParto(TipoParto v) { this.tipoParto = v; }
    public IdadeGestacional getIdadeGestacional() { return idadeGestacional; }
    public void setIdadeGestacional(IdadeGestacional v) { this.idadeGestacional = v; }
    public String getNumFilhosAmamentando() { return numFilhosAmamentando; }
    public void setNumFilhosAmamentando(String v) { this.numFilhosAmamentando = v; }
    public AmamentacaoExclusiva getAmamentacaoExclusiva() { return amamentacaoExclusiva; }
    public void setAmamentacaoExclusiva(AmamentacaoExclusiva v) { this.amamentacaoExclusiva = v; }
    public String getProducaoEstimada() { return producaoEstimada; }
    public void setProducaoEstimada(String v) { this.producaoEstimada = v; }
    public Boolean getInabHiv() { return inabHiv; }
    public void setInabHiv(Boolean v) { this.inabHiv = v != null && v; }
    public Boolean getInabHtlv() { return inabHtlv; }
    public void setInabHtlv(Boolean v) { this.inabHtlv = v != null && v; }
    public Boolean getInabHepatite() { return inabHepatite; }
    public void setInabHepatite(Boolean v) { this.inabHepatite = v != null && v; }
    public Boolean getInabSifilis() { return inabSifilis; }
    public void setInabSifilis(Boolean v) { this.inabSifilis = v != null && v; }
    public Boolean getInabChagas() { return inabChagas; }
    public void setInabChagas(Boolean v) { this.inabChagas = v != null && v; }
    public Boolean getInabMastite() { return inabMastite; }
    public void setInabMastite(Boolean v) { this.inabMastite = v != null && v; }
    public Boolean getInabCandidiaseMam() { return inabCandidiaseMam; }
    public void setInabCandidiaseMam(Boolean v) { this.inabCandidiaseMam = v != null && v; }
    public Boolean getInabRadio() { return inabRadio; }
    public void setInabRadio(Boolean v) { this.inabRadio = v != null && v; }
    public Boolean getAvalMedicamento() { return avalMedicamento; }
    public void setAvalMedicamento(Boolean v) { this.avalMedicamento = v != null && v; }
    public Boolean getAvalAlcool() { return avalAlcool; }
    public void setAvalAlcool(Boolean v) { this.avalAlcool = v != null && v; }
    public Boolean getAvalCigarro() { return avalCigarro; }
    public void setAvalCigarro(Boolean v) { this.avalCigarro = v != null && v; }
    public Boolean getAvalVacina() { return avalVacina; }
    public void setAvalVacina(Boolean v) { this.avalVacina = v != null && v; }
    public Boolean getAvalProcedimento() { return avalProcedimento; }
    public void setAvalProcedimento(Boolean v) { this.avalProcedimento = v != null && v; }
    public Boolean getAvalSilicone() { return avalSilicone; }
    public void setAvalSilicone(Boolean v) { this.avalSilicone = v != null && v; }
    public Boolean getAvalDiabetes() { return avalDiabetes; }
    public void setAvalDiabetes(Boolean v) { this.avalDiabetes = v != null && v; }
    public Boolean getAvalHipertensao() { return avalHipertensao; }
    public void setAvalHipertensao(Boolean v) { this.avalHipertensao = v != null && v; }
    public HistoricoDoacaoLeite getHistoricoDoacao() { return historicoDoacao; }
    public void setHistoricoDoacao(HistoricoDoacaoLeite v) { this.historicoDoacao = v; }
    public ModalidadeColeta getModalidadeColeta() { return modalidadeColeta; }
    public void setModalidadeColeta(ModalidadeColeta v) { this.modalidadeColeta = v; }
    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String v) { this.observacoes = v; }
    public String getUnidade() { return unidade; }
    public void setUnidade(String v) { this.unidade = v; }
    public LocalDate getDataAgendamento() { return dataAgendamento; }
    public void setDataAgendamento(LocalDate v) { this.dataAgendamento = v; }
    public TurnoLeite getTurno() { return turno; }
    public void setTurno(TurnoLeite v) { this.turno = v; }
    public String getComoSoube() { return comoSoube; }
    public void setComoSoube(String v) { this.comoSoube = v; }
    public Boolean getConsentimento() { return consentimento; }
    public void setConsentimento(Boolean v) { this.consentimento = v != null && v; }
    public StatusDoadoraLeite getStatus() { return status; }
    public void setStatus(StatusDoadoraLeite v) { this.status = v; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime v) { this.criadoEm = v; }
    public LocalDateTime getAtualizadoEm() { return atualizadoEm; }
    public void setAtualizadoEm(LocalDateTime v) { this.atualizadoEm = v; }
}
