-- ============================================================
--  FLUXO VITAL — SQL completo (doador + formulários)
--  Execute na ordem mostrada abaixo
-- ============================================================

USE fluxovital;

-- ─── 1. TABELA DOADOR ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doador (
  id          BIGINT       AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(150) NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  telefone    VARCHAR(20)  NOT NULL,
  senha       VARCHAR(255) NOT NULL,
  tipo_doador VARCHAR(50)  DEFAULT NULL,
  status      ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─── 2. FORMULÁRIOS DE DOAÇÃO DE SANGUE ───────────────────────
CREATE TABLE IF NOT EXISTS doadores_sangue (
  id                BIGINT         AUTO_INCREMENT PRIMARY KEY,
  doador_id         BIGINT         DEFAULT NULL,

  -- Identificação
  nome              VARCHAR(150)   NOT NULL,
  cpf               VARCHAR(11)    DEFAULT NULL,
  rg                VARCHAR(20)    DEFAULT NULL,
  nascimento        DATE           DEFAULT NULL,
  sexo              ENUM('masculino','feminino') DEFAULT NULL,
  peso              DOUBLE         DEFAULT NULL,
  altura            DOUBLE         DEFAULT NULL,
  email             VARCHAR(150)   DEFAULT NULL,
  telefone          VARCHAR(20)    DEFAULT NULL,
  endereco          VARCHAR(250)   DEFAULT NULL,
  tipo_sanguineo    VARCHAR(5)     DEFAULT NULL,
  ultima_doacao     DATE           DEFAULT NULL,

  -- Triagem inabilitante
  inab_hiv          TINYINT(1)     DEFAULT 0,
  inab_htlv         TINYINT(1)     DEFAULT 0,
  inab_hepatite     TINYINT(1)     DEFAULT 0,
  inab_sifilis      TINYINT(1)     DEFAULT 0,
  inab_chagas       TINYINT(1)     DEFAULT 0,
  inab_cancer       TINYINT(1)     DEFAULT 0,
  inab_epilepsia    TINYINT(1)     DEFAULT 0,

  -- Triagem avaliação médica
  cond_vacina       TINYINT(1)     DEFAULT 0,
  cond_tatuagem     TINYINT(1)     DEFAULT 0,
  cond_cronica      TINYINT(1)     DEFAULT 0,
  cond_medicamento  TINYINT(1)     DEFAULT 0,
  cond_infeccao     TINYINT(1)     DEFAULT 0,
  cond_cirurgia     TINYINT(1)     DEFAULT 0,
  aval_alcool       TINYINT(1)     DEFAULT 0,
  aval_cigarro      TINYINT(1)     DEFAULT 0,
  aval_vacina       TINYINT(1)     DEFAULT 0,
  aval_gravidez     TINYINT(1)     DEFAULT 0,
  aval_febre        TINYINT(1)     DEFAULT 0,
  aval_diabetes     TINYINT(1)     DEFAULT 0,
  aval_hipertensao  TINYINT(1)     DEFAULT 0,

  historico_doacao  ENUM('nunca','sim','regular') DEFAULT NULL,
  observacoes       VARCHAR(600)   DEFAULT NULL,

  -- Agendamento
  unidade           VARCHAR(100)   DEFAULT NULL,
  data_agendamento  DATE           DEFAULT NULL,
  turno             ENUM('manha','tarde') DEFAULT NULL,
  como_soube        VARCHAR(80)    DEFAULT NULL,
  consentimento     TINYINT(1)     DEFAULT 0,

  -- Controle
  status            ENUM('pendente','aprovado','inabilitado') NOT NULL DEFAULT 'pendente',
  criado_em         DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_ds_doador FOREIGN KEY (doador_id)
    REFERENCES doador(id) ON DELETE SET NULL
);

-- ─── 3. FORMULÁRIOS DE DOAÇÃO DE LEITE ────────────────────────
CREATE TABLE IF NOT EXISTS doadora_leite (
  id                    BIGINT         AUTO_INCREMENT PRIMARY KEY,
  doador_id             BIGINT         DEFAULT NULL,

  -- Identificação
  nome                  VARCHAR(150)   NOT NULL,
  cpf                   VARCHAR(11)    DEFAULT NULL,
  rg                    VARCHAR(20)    DEFAULT NULL,
  nascimento            DATE           DEFAULT NULL,
  email                 VARCHAR(150)   DEFAULT NULL,
  telefone              VARCHAR(20)    DEFAULT NULL,
  endereco              VARCHAR(250)   DEFAULT NULL,

  -- Amamentação
  data_parto            DATE           DEFAULT NULL,
  tipo_parto            ENUM('normal','cesariana') DEFAULT NULL,
  idade_gestacional     ENUM('prematuro_extremo','prematuro_moderado','prematuro_tardio','termo') DEFAULT NULL,
  num_filhos_amamentando VARCHAR(5)    DEFAULT NULL,
  amamentacao_exclusiva  ENUM('sim','parcial','nao') DEFAULT NULL,
  producao_estimada     VARCHAR(20)    DEFAULT NULL,

  -- Triagem inabilitante
  inab_hiv              TINYINT(1)     DEFAULT 0,
  inab_htlv             TINYINT(1)     DEFAULT 0,
  inab_hepatite         TINYINT(1)     DEFAULT 0,
  inab_sifilis          TINYINT(1)     DEFAULT 0,
  inab_chagas           TINYINT(1)     DEFAULT 0,
  inab_mastite          TINYINT(1)     DEFAULT 0,
  inab_candidiase_mam   TINYINT(1)     DEFAULT 0,
  inab_radio            TINYINT(1)     DEFAULT 0,

  -- Triagem avaliação médica
  aval_medicamento      TINYINT(1)     DEFAULT 0,
  aval_alcool           TINYINT(1)     DEFAULT 0,
  aval_cigarro          TINYINT(1)     DEFAULT 0,
  aval_vacina           TINYINT(1)     DEFAULT 0,
  aval_procedimento     TINYINT(1)     DEFAULT 0,
  aval_silicone         TINYINT(1)     DEFAULT 0,
  aval_diabetes         TINYINT(1)     DEFAULT 0,
  aval_hipertensao      TINYINT(1)     DEFAULT 0,

  historico_doacao      ENUM('nunca','sim','regular') DEFAULT NULL,
  modalidade_coleta     ENUM('unidade','domicilio','ambos') DEFAULT NULL,
  observacoes           TEXT           DEFAULT NULL,

  -- Agendamento
  unidade               VARCHAR(100)   DEFAULT NULL,
  data_agendamento      DATE           DEFAULT NULL,
  turno                 ENUM('manha','tarde') DEFAULT NULL,
  como_soube            VARCHAR(80)    DEFAULT NULL,
  consentimento         TINYINT(1)     DEFAULT 0,

  -- Controle
  status                ENUM('pendente','aprovada','inabilitada','em_avaliacao') NOT NULL DEFAULT 'pendente',
  criado_em             DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em         DATETIME       DEFAULT NULL,

  CONSTRAINT fk_dl_doador FOREIGN KEY (doador_id)
    REFERENCES doador(id) ON DELETE SET NULL
);

-- ─── CONSULTAS ÚTEIS ──────────────────────────────────────────

-- Todos os formulários de sangue pendentes
SELECT ds.id, ds.nome, ds.email, ds.telefone, ds.tipo_sanguineo,
       ds.data_agendamento, ds.unidade, ds.status, ds.criado_em
FROM doadores_sangue ds
WHERE ds.status = 'pendente'
ORDER BY ds.criado_em DESC;

-- Formulários de leite pendentes
SELECT dl.id, dl.nome, dl.email, dl.telefone,
       dl.data_parto, dl.producao_estimada, dl.status, dl.criado_em
FROM doadora_leite dl
WHERE dl.status = 'pendente'
ORDER BY dl.criado_em DESC;

-- Histórico de um doador específico (troque o ID)
SELECT 'sangue' AS tipo, id, nome, data_agendamento, status, criado_em
FROM doadores_sangue WHERE doador_id = 1
UNION ALL
SELECT 'leite', id, nome, data_agendamento, status, criado_em
FROM doadora_leite WHERE doador_id = 1
ORDER BY criado_em DESC;
