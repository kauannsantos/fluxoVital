package com.fluxo.fluxovital.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    /** Página inicial */
    @GetMapping("/")
    public String index() {
        return "home/index";
    }

    /** Escolha entre Doador e Instituição */
    @GetMapping("/cadastro/tipos")
    public String tiposCadastros() {
        return "cadastro/tipos_cadastros";
    }

    /** Escolha de categoria do doador */
    @GetMapping("/cadastro/doador/categoria")
    public String escolhaCategoriaDoador() {
        return "cadastro/escolha_categoria";
    }

    /** Seleciona tipo de doação e redireciona para cadastro */
    @GetMapping("/cadastro/doador/selecionar")
    public String selecionarTipo(@RequestParam String tipo, HttpSession session) {
        session.setAttribute("tipo_doacao", tipo);
        return "redirect:/doador/cadastro";
    }
}
