package com.fluxo.fluxovital.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "doadores_sangue")
public class DoadorSangue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Identificação
    private String nome;
    private String cpf;
    private String rg;
    private LocalDate nascimento;
    @Enumerated(EnumType.STRING)
    private Sexo sexo;
    private Double peso;
    private String email;
    private String telefone;

    // Tipo sanguíneo
    @Column(name = "tipo_sanguineo")
    private String tipoSanguineo;

    // Triagem — checkboxes (0 = não marcado, 1 = marcado)
    @Column(name = "cond_vacina")
    private Boolean condVacina;
    @Column(name = "cond_tatuagem")
    private Boolean condTatuagem;
    @Column(name = "cond_cronica")
    private Boolean condCronica;
    @Column(name = "cond_medicamento")
    private Boolean condMedicamento;
    @Column(name = "cond_infeccao")
    private Boolean condInfeccao;
    @Column(name = "cond_cirurgia")
    private Boolean condCirurgia;

    @Enumerated(EnumType.STRING)
    @Column(name = "historico_doacao")
    private HistoricoDoacao historicoDoacao;

    private String observacoes;

    // Agendamento no formularioi
    private String unidade;
    @Column(name = "data_agendamento")
    private LocalDate dataAgendamento;
    @Enumerated(EnumType.STRING)
    private Turno turno;
    @Column(name = "como_soube")
    private String comoSoube;

    // Controle interno
    @Enumerated(EnumType.STRING)
    private StatusDoador status;
    @Column(name = "criado_em")
    private LocalDate criadoEm;

    // Construtor padrão (necessário para JPA)
    public DoadorSangue() {
    }

    // GETTERS E SETTERS

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }

    public String getRg() { return rg; }
    public void setRg(String rg) { this.rg = rg; }

    public LocalDate getNascimento() { return nascimento; }
    public void setNascimento(LocalDate nascimento) { this.nascimento = nascimento; }

    public Sexo getSexo() { return sexo; }
    public void setSexo(Sexo sexo) { this.sexo = sexo; }

    public Double getPeso() { return peso; }
    public void setPeso(Double peso) { this.peso = peso; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getTipoSanguineo() { return tipoSanguineo; }
    public void setTipoSanguineo(String tipoSanguineo) { this.tipoSanguineo = tipoSanguineo; }

    public Boolean getCondVacina() { return condVacina; }
    public void setCondVacina(Boolean condVacina) { this.condVacina = condVacina; }

    public Boolean getCondTatuagem() { return condTatuagem; }
    public void setCondTatuagem(Boolean condTatuagem) { this.condTatuagem = condTatuagem; }

    public Boolean getCondCronica() { return condCronica; }
    public void setCondCronica(Boolean condCronica) { this.condCronica = condCronica; }

    public Boolean getCondMedicamento() { return condMedicamento; }
    public void setCondMedicamento(Boolean condMedicamento) { this.condMedicamento = condMedicamento; }

    public Boolean getCondInfeccao() { return condInfeccao; }
    public void setCondInfeccao(Boolean condInfeccao) { this.condInfeccao = condInfeccao; }

    public Boolean getCondCirurgia() { return condCirurgia; }
    public void setCondCirurgia(Boolean condCirurgia) { this.condCirurgia = condCirurgia; }

    public HistoricoDoacao getHistoricoDoacao() { return historicoDoacao; }
    public void setHistoricoDoacao(HistoricoDoacao historicoDoacao) { this.historicoDoacao = historicoDoacao; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }

    public String getUnidade() { return unidade; }
    public void setUnidade(String unidade) { this.unidade = unidade; }

    public LocalDate getDataAgendamento() { return dataAgendamento; }
    public void setDataAgendamento(LocalDate dataAgendamento) { this.dataAgendamento = dataAgendamento; }

    public Turno getTurno() { return turno; }
    public void setTurno(Turno turno) { this.turno = turno; }

    public String getComoSoube() { return comoSoube; }
    public void setComoSoube(String comoSoube) { this.comoSoube = comoSoube; }

    public StatusDoador getStatus() { return status; }
    public void setStatus(StatusDoador status) { this.status = status; }

    public LocalDate getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDate criadoEm) { this.criadoEm = criadoEm; }
}

enum Sexo {
    M, F
}

enum HistoricoDoacao {
    nunca, sim, regular
}

enum Turno {
    manha, tarde
}

enum StatusDoador {
    pendente, aprovado, inabilitado
}