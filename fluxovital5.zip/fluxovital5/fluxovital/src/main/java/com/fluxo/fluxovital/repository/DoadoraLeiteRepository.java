package com.fluxo.fluxovital.repository;

import com.fluxo.fluxovital.model.DoadoraLeite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DoadoraLeiteRepository extends JpaRepository<DoadoraLeite, Long> {
}