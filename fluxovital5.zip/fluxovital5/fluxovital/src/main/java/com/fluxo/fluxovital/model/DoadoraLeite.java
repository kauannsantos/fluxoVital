package com.fluxo.fluxovital.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "doadora_leite")
public class DoadoraLeite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Identificação
    private String nome;
    private String cpf;
    private String rg;
    private LocalDate nascimento;
    private String email;
    private String telefone;
    private String endereco;

    // Dados da amamentação
    @Column(name = "data_parto")
    private LocalDate dataParto;
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_parto")
    private TipoParto tipoParto;
    @Enumerated(EnumType.STRING)
    @Column(name = "idade_gestacional")
    private IdadeGestacional idadeGestacional;

    @Column(name = "num_filhos_amamentando")
    private String numFilhosAmamentando; // Alterado para String

    @Enumerated(EnumType.STRING)
    @Column(name = "amamentacao_exclusiva")
    private AmamentacaoExclusiva amamentacaoExclusiva;

    @Column(name = "producao_estimada")
    private String producaoEstimada; // Alterado para String para aceitar "500_1000", etc.

    // Triagem — condições inabilitantes
    @Column(name = "inab_hiv")
    private Boolean inabHiv;
    @Column(name = "inab_htlv")
    private Boolean inabHtlv;
    @Column(name = "inab_hepatite")
    private Boolean inabHepatite;
    @Column(name = "inab_sifilis")
    private Boolean inabSifilis;
    @Column(name = "inab_chagas")
    private Boolean inabChagas;
    @Column(name = "inab_mastite")
    private Boolean inabMastite;
    @Column(name = "inab_candidiase_mam")
    private Boolean inabCandidiaseMam;
    @Column(name = "inab_radio")
    private Boolean inabRadio;

    // Triagem — condições para avaliação médica
    @Column(name = "aval_medicamento")
    private Boolean avalMedicamento;
    @Column(name = "aval_alcool")
    private Boolean avalAlcool;
    @Column(name = "aval_cigarro")
    private Boolean avalCigarro;
    @Column(name = "aval_vacina")
    private Boolean avalVacina;
    @Column(name = "aval_procedimento")
    private Boolean avalProcedimento;
    @Column(name = "aval_silicone")
    private Boolean avalSilicone;
    @Column(name = "aval_diabetes")
    private Boolean avalDiabetes;
    @Column(name = "aval_hipertensao")
    private Boolean avalHipertensao;

    // Histórico e coleta
    @Enumerated(EnumType.STRING)
    @Column(name = "historico_doacao")
    private HistoricoDoacaoLeite historicoDoacao;
    @Enumerated(EnumType.STRING)
    @Column(name = "modalidade_coleta")
    private ModalidadeColeta modalidadeColeta;
    private String observacoes;

    // Agendamento
    @Enumerated(EnumType.STRING)
    private UnidadeLeite unidade;
    @Column(name = "data_agendamento")
    private LocalDate dataAgendamento;
    @Enumerated(EnumType.STRING)
    private TurnoLeite turno;
    @Enumerated(EnumType.STRING)
    @Column(name = "como_soube")
    private ComoSoube comoSoube;

    // Consentimento e status
    private Boolean consentimento;
    @Enumerated(EnumType.STRING)
    private StatusDoadoraLeite status;

    // Metadados
    @Column(name = "criado_em")
    private LocalDateTime criadoEm;
    @Column(name = "atualizado_em")
    private LocalDateTime atualizadoEm;

    public DoadoraLeite() {}

    // GETTERS E SETTERS
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }
    public String getRg() { return rg; }
    public void setRg(String rg) { this.rg = rg; }
    public LocalDate getNascimento() { return nascimento; }
    public void setNascimento(LocalDate nascimento) { this.nascimento = nascimento; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public LocalDate getDataParto() { return dataParto; }
    public void setDataParto(LocalDate dataParto) { this.dataParto = dataParto; }
    public TipoParto getTipoParto() { return tipoParto; }
    public void setTipoParto(TipoParto tipoParto) { this.tipoParto = tipoParto; }
    public IdadeGestacional getIdadeGestacional() { return idadeGestacional; }
    public void setIdadeGestacional(IdadeGestacional idadeGestacional) { this.idadeGestacional = idadeGestacional; }
    public String getNumFilhosAmamentando() { return numFilhosAmamentando; }
    public void setNumFilhosAmamentando(String numFilhosAmamentando) { this.numFilhosAmamentando = numFilhosAmamentando; }
    public AmamentacaoExclusiva getAmamentacaoExclusiva() { return amamentacaoExclusiva; }
    public void setAmamentacaoExclusiva(AmamentacaoExclusiva amamentacaoExclusiva) { this.amamentacaoExclusiva = amamentacaoExclusiva; }
    public String getProducaoEstimada() { return producaoEstimada; }
    public void setProducaoEstimada(String producaoEstimada) { this.producaoEstimada = producaoEstimada; }
    public Boolean getInabHiv() { return inabHiv; }
    public void setInabHiv(Boolean inabHiv) { this.inabHiv = inabHiv; }
    public Boolean getInabHtlv() { return inabHtlv; }
    public void setInabHtlv(Boolean inabHtlv) { this.inabHtlv = inabHtlv; }
    public Boolean getInabHepatite() { return inabHepatite; }
    public void setInabHepatite(Boolean inabHepatite) { this.inabHepatite = inabHepatite; }
    public Boolean getInabSifilis() { return inabSifilis; }
    public void setInabSifilis(Boolean inabSifilis) { this.inabSifilis = inabSifilis; }
    public Boolean getInabChagas() { return inabChagas; }
    public void setInabChagas(Boolean inabChagas) { this.inabChagas = inabChagas; }
    public Boolean getInabMastite() { return inabMastite; }
    public void setInabMastite(Boolean inabMastite) { this.inabMastite = inabMastite; }
    public Boolean getInabCandidiaseMam() { return inabCandidiaseMam; }
    public void setInabCandidiaseMam(Boolean inabCandidiaseMam) { this.inabCandidiaseMam = inabCandidiaseMam; }
    public Boolean getInabRadio() { return inabRadio; }
    public void setInabRadio(Boolean inabRadio) { this.inabRadio = inabRadio; }
    public Boolean getAvalMedicamento() { return avalMedicamento; }
    public void setAvalMedicamento(Boolean avalMedicamento) { this.avalMedicamento = avalMedicamento; }
    public Boolean getAvalAlcool() { return avalAlcool; }
    public void setAvalAlcool(Boolean avalAlcool) { this.avalAlcool = avalAlcool; }
    public Boolean getAvalCigarro() { return avalCigarro; }
    public void setAvalCigarro(Boolean avalCigarro) { this.avalCigarro = avalCigarro; }
    public Boolean getAvalVacina() { return avalVacina; }
    public void setAvalVacina(Boolean avalVacina) { this.avalVacina = avalVacina; }
    public Boolean getAvalProcedimento() { return avalProcedimento; }
    public void setAvalProcedimento(Boolean avalProcedimento) { this.avalProcedimento = avalProcedimento; }
    public Boolean getAvalSilicone() { return avalSilicone; }
    public void setAvalSilicone(Boolean avalSilicone) { this.avalSilicone = avalSilicone; }
    public Boolean getAvalDiabetes() { return avalDiabetes; }
    public void setAvalDiabetes(Boolean avalDiabetes) { this.avalDiabetes = avalDiabetes; }
    public Boolean getAvalHipertensao() { return avalHipertensao; }
    public void setAvalHipertensao(Boolean avalHipertensao) { this.avalHipertensao = avalHipertensao; }
    public HistoricoDoacaoLeite getHistoricoDoacao() { return historicoDoacao; }
    public void setHistoricoDoacao(HistoricoDoacaoLeite historicoDoacao) { this.historicoDoacao = historicoDoacao; }
    public ModalidadeColeta getModalidadeColeta() { return modalidadeColeta; }
    public void setModalidadeColeta(ModalidadeColeta modalidadeColeta) { this.modalidadeColeta = modalidadeColeta; }
    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public UnidadeLeite getUnidade() { return unidade; }
    public void setUnidade(UnidadeLeite unidade) { this.unidade = unidade; }
    public LocalDate getDataAgendamento() { return dataAgendamento; }
    public void setDataAgendamento(LocalDate dataAgendamento) { this.dataAgendamento = dataAgendamento; }
    public TurnoLeite getTurno() { return turno; }
    public void setTurno(TurnoLeite turno) { this.turno = turno; }
    public ComoSoube getComoSoube() { return comoSoube; }
    public void setComoSoube(ComoSoube comoSoube) { this.comoSoube = comoSoube; }
    public Boolean getConsentimento() { return consentimento; }
    public void setConsentimento(Boolean consentimento) { this.consentimento = consentimento; }
    public StatusDoadoraLeite getStatus() { return status; }
    public void setStatus(StatusDoadoraLeite status) { this.status = status; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }
    public LocalDateTime getAtualizadoEm() { return atualizadoEm; }
    public void setAtualizadoEm(LocalDateTime atualizadoEm) { this.atualizadoEm = atualizadoEm; }
}

enum TipoParto { normal, cesariana }
enum IdadeGestacional { prematuro_extremo, prematuro_moderado, prematuro_tardio, termo }
enum AmamentacaoExclusiva { sim, parcial, nao }
enum HistoricoDoacaoLeite { nunca, sim, regular }
enum ModalidadeColeta { unidade, domicilio, ambos }
enum UnidadeLeite { blh_central, blh_hgcc, blh_huwc, blh_ijf, domicilio }
enum TurnoLeite { manha, tarde }
enum ComoSoube { maternidade, pediatra, indicacao, redes, campanha, outro }
enum StatusDoadoraLeite { pendente, aprovada, inabilitada, em_avaliacao }