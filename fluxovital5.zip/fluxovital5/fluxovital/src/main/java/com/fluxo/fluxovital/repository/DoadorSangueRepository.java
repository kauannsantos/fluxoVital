package com.fluxo.fluxovital.repository;

import com.fluxo.fluxovital.model.DoadorSangue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoadorSangueRepository extends JpaRepository<DoadorSangue, Long> {
}