-- ============================================================
--  FLUXO VITAL — Doador
-- ============================================================

USE fluxovital;

-- Remove tabelas antigas se existirem (ordem importa por causa das FK)
DROP TABLE IF EXISTS agendamentos;
DROP TABLE IF EXISTS doador;

-- ─── TABELA DOADOR ────────────────────────────────────────────
-- BIGINT para bater com o tipo Long do Java (JPA/Hibernate)
CREATE TABLE doador (
  id          BIGINT        AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(150)  NOT NULL,
  email       VARCHAR(150)  NOT NULL UNIQUE,
  telefone    VARCHAR(20)   NOT NULL,
  senha       VARCHAR(255)  NOT NULL,
  tipo_doador VARCHAR(50)   DEFAULT NULL,
  status      ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  criado_em   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─── TABELA AGENDAMENTOS ──────────────────────────────────────
CREATE TABLE agendamentos (
  id            BIGINT    AUTO_INCREMENT PRIMARY KEY,
  id_doador     BIGINT    NOT NULL,
  tipo_doacao   ENUM('sangue','medula','leite') NOT NULL,
  data_agendada DATE      NOT NULL,
  hora_agendada TIME      DEFAULT NULL,
  status        ENUM('pendente','confirmado','realizado','cancelado') NOT NULL DEFAULT 'pendente',
  observacoes   TEXT      DEFAULT NULL,
  criado_em     DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_agendamento_doador
    FOREIGN KEY (id_doador) REFERENCES doador(id)
    ON DELETE CASCADE
);

-- ─── CONSULTAS ────────────────────────────────────────────────

-- Todos os doadores
SELECT id, nome, email, telefone, tipo_doador, status, criado_em
FROM doador
ORDER BY criado_em DESC;

-- Doadores ativos
SELECT id, nome, email, tipo_doador, criado_em
FROM doador
WHERE status = 'ativo'
ORDER BY criado_em DESC;

-- Doadores por tipo de doação
SELECT id, nome, email, telefone
FROM doador
WHERE tipo_doador = 'sangue'   -- trocar por 'medula' ou 'leite'
ORDER BY nome;

-- Agendamentos pendentes com nome do doador
SELECT a.id, d.nome AS doador, a.tipo_doacao,
       a.data_agendada, a.hora_agendada, a.status
FROM agendamentos a
JOIN doador d ON d.id = a.id_doador
WHERE a.status = 'pendente'
ORDER BY a.data_agendada;

-- Todos os agendamentos de um doador específico
SELECT a.id, a.tipo_doacao, a.data_agendada, a.hora_agendada, a.status
FROM agendamentos a
WHERE a.id_doador = 1   -- trocar pelo id desejado
ORDER BY a.data_agendada DESC;