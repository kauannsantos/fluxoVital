-- ============================================================
--  FLUXO VITAL — Instituição
--  ⚠️  Execute APÓS o 01_doador.sql
-- ============================================================

USE fluxovital;

-- Remove tabelas antigas se existirem (ordem importa por causa das FK)
DROP TABLE IF EXISTS doacoes_recebidas;
DROP TABLE IF EXISTS campanhas;
DROP TABLE IF EXISTS instituicoes;

-- ─── TABELA INSTITUICOES ──────────────────────────────────────
CREATE TABLE instituicoes (
  id            BIGINT        AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(150)  NOT NULL,
  cnpj          CHAR(14)      NOT NULL UNIQUE,
  email         VARCHAR(100)  NOT NULL UNIQUE,
  senha         VARCHAR(255)  NOT NULL,
  telefone      VARCHAR(20)   DEFAULT NULL,
  categoria     ENUM(
                  'BANCOS_DE_DOACAO',
                  'HOSPITAIS',
                  'ONGS',
                  'OUTROS'
                )             NOT NULL,
  endereco      VARCHAR(200)  DEFAULT NULL,
  cidade        VARCHAR(100)  NOT NULL,
  estado        CHAR(2)       NOT NULL,
  cep           VARCHAR(10)   DEFAULT NULL,
  data_cadastro DATE          NOT NULL DEFAULT (CURRENT_DATE)
);

-- ─── TABELA CAMPANHAS ─────────────────────────────────────────
CREATE TABLE campanhas (
  id               BIGINT        AUTO_INCREMENT PRIMARY KEY,
  id_instituicao   BIGINT        NOT NULL,
  titulo           VARCHAR(200)  NOT NULL,
  descricao        TEXT          DEFAULT NULL,
  tipo_doacao      ENUM('sangue','medula','leite','todos') NOT NULL DEFAULT 'todos',
  data_inicio      DATE          NOT NULL,
  data_fim         DATE          DEFAULT NULL,
  status           ENUM('ativa','encerrada','suspensa') NOT NULL DEFAULT 'ativa',
  criado_em        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_campanha_instituicao
    FOREIGN KEY (id_instituicao) REFERENCES instituicoes(id)
    ON DELETE CASCADE
);

-- ─── TABELA DOACOES_RECEBIDAS ─────────────────────────────────
CREATE TABLE doacoes_recebidas (
  id               BIGINT     AUTO_INCREMENT PRIMARY KEY,
  id_doador        BIGINT     NOT NULL,
  id_instituicao   BIGINT     NOT NULL,
  tipo_doacao      ENUM('sangue','medula','leite') NOT NULL,
  data_doacao      DATE       NOT NULL,
  volume_ml        INT        DEFAULT NULL,
  tipo_sanguineo   VARCHAR(5) DEFAULT NULL,
  status           ENUM('recebida','processada','descartada') NOT NULL DEFAULT 'recebida',
  observacoes      TEXT       DEFAULT NULL,
  criado_em        DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_doacao_doador
    FOREIGN KEY (id_doador) REFERENCES doador(id)
    ON DELETE RESTRICT,

  CONSTRAINT fk_doacao_instituicao
    FOREIGN KEY (id_instituicao) REFERENCES instituicoes(id)
    ON DELETE RESTRICT
);

-- ─── CONSULTAS ────────────────────────────────────────────────

-- Todas as instituições
SELECT id, nome, cnpj, email, categoria, cidade, estado, data_cadastro
FROM instituicoes
ORDER BY categoria, nome;

-- Instituições por categoria
SELECT id, nome, cnpj, cidade, estado
FROM instituicoes
WHERE categoria = 'HOSPITAIS'   -- trocar pela categoria desejada
ORDER BY nome;

-- Campanhas ativas com nome da instituição
SELECT c.id, i.nome AS instituicao, c.titulo,
       c.tipo_doacao, c.data_inicio, c.data_fim
FROM campanhas c
JOIN instituicoes i ON i.id = c.id_instituicao
WHERE c.status = 'ativa'
ORDER BY c.data_inicio;

-- Doações recebidas por uma instituição com nome do doador
SELECT dr.id, d.nome AS doador, dr.tipo_doacao,
       dr.data_doacao, dr.tipo_sanguineo, dr.volume_ml, dr.status
FROM doacoes_recebidas dr
JOIN doador d ON d.id = dr.id_doador
WHERE dr.id_instituicao = 1   -- trocar pelo id desejado
ORDER BY dr.data_doacao DESC;

-- Total de doações recebidas por instituição
SELECT i.nome AS instituicao, COUNT(dr.id) AS total_doacoes
FROM doacoes_recebidas dr
JOIN instituicoes i ON i.id = dr.id_instituicao
GROUP BY i.id, i.nome
ORDER BY total_doacoes DESC;