package com.fluxo.fluxovital.controller;

import com.fluxo.fluxovital.model.CategoriaInstituicao;
import com.fluxo.fluxovital.model.Instituicao;
import com.fluxo.fluxovital.repository.InstituicaoRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class InstituicaoController {

    private final InstituicaoRepository instituicaoRepository;
    private final PasswordEncoder passwordEncoder;

    public InstituicaoController(InstituicaoRepository instituicaoRepository, PasswordEncoder passwordEncoder) {
        this.instituicaoRepository = instituicaoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ─── ESCOLHA DE CATEGORIA ─────────────────────────────────────────────────

    @GetMapping("/instituicao/categoria")
    public String escolhaCategoria(Model model) {
        model.addAttribute("categorias", CategoriaInstituicao.values());
        return "instituicao/escolha_categoria";
    }

    // ─── LOGIN ────────────────────────────────────────────────────────────────

    @GetMapping("/instituicao/login")
    public String exibirLogin(@RequestParam(required = false) String categoria, Model model) {
        if (categoria == null || categoria.isBlank()) {
            return "redirect:/instituicao/categoria";
        }
        // resolve enum para pegar a descrição legível (ex: BANCOS_DE_DOACAO → "Bancos de Doação")
        try {
            CategoriaInstituicao cat = CategoriaInstituicao.fromDescricao(categoria);
            model.addAttribute("categoria", cat.name());           // nome do enum para o hidden field
            model.addAttribute("categoriaLabel", cat.getDescricao()); // label para exibição
        } catch (IllegalArgumentException e) {
            model.addAttribute("categoria", categoria);
            model.addAttribute("categoriaLabel", categoria);
        }
        return "instituicao/login";
    }

    @PostMapping("/instituicao/login")
    public String processarLogin(
            @RequestParam String email,
            @RequestParam String senha,
            @RequestParam String categoria,
            HttpSession session,
            RedirectAttributes redirectAttributes
    ) {
        CategoriaInstituicao cat;
        try {
            cat = CategoriaInstituicao.fromDescricao(categoria);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("erro", "Categoria inválida.");
            return "redirect:/instituicao/categoria";
        }

        if (email.isBlank() || senha.isBlank()) {
            redirectAttributes.addFlashAttribute("erro", "Preencha email e senha.");
            return "redirect:/instituicao/login?categoria=" + categoria;
        }

        Optional<Instituicao> opt = instituicaoRepository.findByEmailAndCategoria(email.trim(), cat);

        if (opt.isEmpty()) {
            redirectAttributes.addFlashAttribute("erro", "Usuário não encontrado na categoria selecionada.");
            return "redirect:/instituicao/login?categoria=" + categoria;
        }

        Instituicao inst = opt.get();

        if (!passwordEncoder.matches(senha, inst.getSenha())) {
            redirectAttributes.addFlashAttribute("erro", "Senha incorreta.");
            return "redirect:/instituicao/login?categoria=" + categoria;
        }

        preencherSessao(session, inst);
        return "redirect:/instituicao/home";
    }

    // ─── CADASTRO ─────────────────────────────────────────────────────────────

    @GetMapping("/instituicao/cadastro")
    public String exibirCadastro(@RequestParam(required = false) String categoria, Model model) {
        if (categoria == null || categoria.isBlank()) {
            return "redirect:/instituicao/categoria";
        }
        try {
            CategoriaInstituicao cat = CategoriaInstituicao.fromDescricao(categoria);
            model.addAttribute("categoria", cat.name());
            model.addAttribute("categoriaLabel", cat.getDescricao());
        } catch (IllegalArgumentException e) {
            model.addAttribute("categoria", categoria);
            model.addAttribute("categoriaLabel", categoria);
        }
        return "instituicao/cadastro";
    }

    @PostMapping("/instituicao/cadastro")
    public String processarCadastro(
            @RequestParam String nome,
            @RequestParam String cnpj,
            @RequestParam String email,
            @RequestParam String senha,
            @RequestParam("confirma_senha") String confirmaSenha,
            @RequestParam(required = false, defaultValue = "") String telefone,
            @RequestParam(required = false, defaultValue = "") String endereco,
            @RequestParam String cidade,
            @RequestParam String estado,
            @RequestParam(required = false, defaultValue = "") String cep,
            @RequestParam String categoria,
            HttpSession session,
            RedirectAttributes redirectAttributes
    ) {
        // Validações básicas
        if (nome.isBlank() || cnpj.isBlank() || email.isBlank() || senha.isBlank()
                || cidade.isBlank() || estado.isBlank()) {
            redirectAttributes.addFlashAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "redirect:/instituicao/cadastro?categoria=" + categoria;
        }

        if (!senha.equals(confirmaSenha)) {
            redirectAttributes.addFlashAttribute("erro", "As senhas não coincidem.");
            return "redirect:/instituicao/cadastro?categoria=" + categoria;
        }

        String cnpjNumerico = cnpj.replaceAll("\\D", "");
        if (cnpjNumerico.length() != 14) {
            redirectAttributes.addFlashAttribute("erro", "CNPJ inválido. Informe 14 dígitos.");
            return "redirect:/instituicao/cadastro?categoria=" + categoria;
        }

        if (instituicaoRepository.existsByCnpj(cnpjNumerico)) {
            redirectAttributes.addFlashAttribute("erro", "CNPJ já cadastrado.");
            return "redirect:/instituicao/cadastro?categoria=" + categoria;
        }

        if (instituicaoRepository.findByEmail(email.trim()).isPresent()) {
            redirectAttributes.addFlashAttribute("erro", "E-mail já cadastrado.");
            return "redirect:/instituicao/cadastro?categoria=" + categoria;
        }

        // Resolve categoria — aceita descrição ou nome do enum
        CategoriaInstituicao cat;
        try {
            cat = CategoriaInstituicao.fromDescricao(categoria);
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("erro", "Categoria inválida. Selecione novamente.");
            return "redirect:/instituicao/categoria";
        }

        // Salva a instituição
        Instituicao nova = new Instituicao();
        nova.setNome(nome.trim());
        nova.setCnpj(cnpjNumerico);
        nova.setEmail(email.trim());
        nova.setSenha(passwordEncoder.encode(senha));
        nova.setTelefone(telefone.trim());
        nova.setCategoria(cat);
        nova.setEndereco(endereco.trim());
        nova.setCidade(cidade.trim());
        nova.setEstado(estado.trim().toUpperCase());
        nova.setCep(cep.trim());

        instituicaoRepository.save(nova);

        // Já loga na sessão — não precisa fazer login de novo
        preencherSessao(session, nova);

        redirectAttributes.addFlashAttribute("sucesso", "Cadastro realizado com sucesso! Bem-vindo(a).");
        return "redirect:/instituicao/home";
    }

    // ─── HOME ─────────────────────────────────────────────────────────────────

    @GetMapping("/instituicao/home")
    public String home(HttpSession session, Model model) {
        if (session.getAttribute("instituicao_id") == null) {
            return "redirect:/instituicao/categoria";
        }
        model.addAttribute("nome", session.getAttribute("instituicao_nome"));
        model.addAttribute("categoria", session.getAttribute("instituicao_categoria"));
        return "instituicao/home";
    }

    // ─── GERENCIAR ────────────────────────────────────────────────────────────

    @GetMapping("/instituicao/gerenciar")
    public String gerenciar(HttpSession session, Model model) {
        if (session.getAttribute("instituicao_id") == null) {
            return "redirect:/instituicao/categoria";
        }
        Long id = (Long) session.getAttribute("instituicao_id");
        instituicaoRepository.findById(id).ifPresent(inst -> model.addAttribute("instituicao", inst));
        return "instituicao/gerenciar";
    }

    // ─── EDITAR ───────────────────────────────────────────────────────────────

    @GetMapping("/instituicao/editar")
    public String exibirEditar(HttpSession session, Model model) {
        if (session.getAttribute("instituicao_id") == null) {
            return "redirect:/instituicao/categoria";
        }
        Long id = (Long) session.getAttribute("instituicao_id");
        instituicaoRepository.findById(id).ifPresent(inst -> model.addAttribute("instituicao", inst));
        return "instituicao/editar";
    }

    @PostMapping("/instituicao/editar")
    public String processarEdicao(
            @RequestParam String nome,
            @RequestParam String cnpj,
            @RequestParam String email,
            @RequestParam(required = false, defaultValue = "") String telefone,
            @RequestParam(required = false, defaultValue = "") String endereco,
            @RequestParam(required = false, defaultValue = "") String cep,
            @RequestParam(required = false) String senha,
            HttpSession session,
            RedirectAttributes redirectAttributes
    ) {
        if (session.getAttribute("instituicao_id") == null) {
            return "redirect:/instituicao/categoria";
        }

        if (nome.isBlank() || cnpj.isBlank() || email.isBlank()) {
            redirectAttributes.addFlashAttribute("erro", "Preencha todos os campos obrigatórios.");
            return "redirect:/instituicao/editar";
        }

        String cnpjNumerico = cnpj.replaceAll("\\D", "");
        if (cnpjNumerico.length() != 14) {
            redirectAttributes.addFlashAttribute("erro", "CNPJ inválido.");
            return "redirect:/instituicao/editar";
        }

        Long id = (Long) session.getAttribute("instituicao_id");
        Optional<Instituicao> opt = instituicaoRepository.findById(id);

        if (opt.isEmpty()) {
            return "redirect:/instituicao/categoria";
        }

        Instituicao inst = opt.get();
        inst.setNome(nome.trim());
        inst.setCnpj(cnpjNumerico);
        inst.setEmail(email.trim());
        inst.setTelefone(telefone.trim());
        inst.setEndereco(endereco.trim());
        inst.setCep(cep.trim());

        if (senha != null && !senha.isBlank()) {
            inst.setSenha(passwordEncoder.encode(senha));
        }

        instituicaoRepository.save(inst);

        session.setAttribute("instituicao_nome", inst.getNome());
        redirectAttributes.addFlashAttribute("sucesso", "Dados atualizados com sucesso!");
        return "redirect:/instituicao/editar";
    }

    // ─── LOGOUT ───────────────────────────────────────────────────────────────

    @GetMapping("/instituicao/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    // ─── HELPER ───────────────────────────────────────────────────────────────

    private void preencherSessao(HttpSession session, Instituicao inst) {
        session.setAttribute("instituicao_id", inst.getId());
        session.setAttribute("instituicao_nome", inst.getNome());
        session.setAttribute("instituicao_email", inst.getEmail());
        session.setAttribute("instituicao_categoria", inst.getCategoria().getDescricao());
    }
}
