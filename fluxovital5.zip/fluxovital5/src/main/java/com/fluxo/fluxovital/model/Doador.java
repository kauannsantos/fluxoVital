package com.fluxo.fluxovital.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "doador")
public class Doador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false, length = 20)
    private String telefone;

    @Column(nullable = false, length = 255)
    private String senha;

    @Column(name = "tipo_doador")
    private String tipoDoador;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusDoador status = StatusDoador.ativo;

    @Column(name = "criado_em", updatable = false)
    private LocalDateTime criadoEm;

    @PrePersist
    public void prePersist() {
        if (this.criadoEm == null) {
            this.criadoEm = LocalDateTime.now();
        }
    }

    public enum StatusDoador { ativo, inativo }

    public Doador() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public String getTipoDoador() { return tipoDoador; }
    public void setTipoDoador(String tipoDoador) { this.tipoDoador = tipoDoador; }

    public StatusDoador getStatus() { return status; }
    public void setStatus(StatusDoador status) { this.status = status; }

    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }
}
