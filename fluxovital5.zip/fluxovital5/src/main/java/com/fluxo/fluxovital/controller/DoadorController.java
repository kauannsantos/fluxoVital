package com.fluxo.fluxovital.controller;

import com.fluxo.fluxovital.model.Doador;
import com.fluxo.fluxovital.repository.DoadorRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.Year;
import java.util.List;
import java.util.Optional;

@Controller
public class DoadorController {

    private final DoadorRepository doadorRepository;
    private final PasswordEncoder passwordEncoder;

    public DoadorController(DoadorRepository doadorRepository, PasswordEncoder passwordEncoder) {
        this.doadorRepository = doadorRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /** Formulário de cadastro do doador */
    @GetMapping("/doador/cadastro")
    public String exibirCadastro(HttpSession session, Model model) {
        if (session.getAttribute("tipo_doacao") == null) {
            session.setAttribute("tipo_doacao", "sangue");
        }
        model.addAttribute("tipoDoacao", session.getAttribute("tipo_doacao"));
        model.addAttribute("anoAtual", Year.now().getValue());
        return "doador/cadastro/cadastro_doador";
    }

    @PostMapping("/doador/cadastro")
    public String processarCadastro(
            @RequestParam String nome,
            @RequestParam String email,
            @RequestParam String telefone,
            @RequestParam String senha,
            @RequestParam("confirma_senha") String confirmaSenha,
            HttpSession session,
            RedirectAttributes redirectAttributes
    ) {
        String tipoDoador = (String) session.getAttribute("tipo_doacao");
        List<String> tiposValidos = List.of("sangue", "medula", "leite");

        if (tipoDoador == null || !tiposValidos.contains(tipoDoador)) {
            redirectAttributes.addFlashAttribute("erro", "Tipo de doação inválido. Por favor, selecione novamente.");
            return "redirect:/cadastro/doador/categoria";
        }

        if (nome.isBlank() || email.isBlank() || telefone.isBlank() || senha.isBlank() || confirmaSenha.isBlank()) {
            redirectAttributes.addFlashAttribute("erro", "Preencha todos os campos corretamente.");
            return "redirect:/doador/cadastro";
        }

        if (!senha.equals(confirmaSenha)) {
            redirectAttributes.addFlashAttribute("erro", "As senhas não coincidem.");
            return "redirect:/doador/cadastro";
        }

        Optional<Doador> doadorExistente = doadorRepository.findByEmail(email);

        if (doadorExistente.isPresent()) {
            Doador doador = doadorExistente.get();
            if (passwordEncoder.matches(senha, doador.getSenha())) {
                session.setAttribute("doador_id", doador.getId());
                session.setAttribute("doador_nome", doador.getNome());
                session.setAttribute("tipo_doacao", doador.getTipoDoador());
                return "redirect:/doador/home";
            } else {
                redirectAttributes.addFlashAttribute("erro", "Este e-mail já está cadastrado, mas a senha está incorreta.");
                return "redirect:/doador/cadastro";
            }
        }

        Doador novoDoador = new Doador();
        novoDoador.setNome(nome.trim());
        novoDoador.setEmail(email.trim());
        novoDoador.setTelefone(telefone.trim());
        novoDoador.setSenha(passwordEncoder.encode(senha));
        novoDoador.setTipoDoador(tipoDoador);

        doadorRepository.save(novoDoador);

        session.setAttribute("doador_id", novoDoador.getId());
        session.setAttribute("doador_nome", novoDoador.getNome());

        // Novo cadastro vai direto pra home — o doador agenda a doação de lá
        return "redirect:/doador/home";
    }

    // ── FORMULÁRIOS DE AGENDAMENTO ──────────────────────────────────

    @GetMapping("/doador/sangue/form")
    public String formSangue(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        model.addAttribute("doadorNome", session.getAttribute("doador_nome"));
        return "doador/sangue/form";
    }

    @PostMapping("/doador/sangue/form")
    public String salvarSangue(HttpSession session, RedirectAttributes redirectAttributes) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        redirectAttributes.addFlashAttribute("sucesso", "Doação de sangue agendada com sucesso!");
        return "redirect:/doador/home";
    }

    @GetMapping("/doador/medula/form")
    public String formMedula(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        model.addAttribute("doadorNome", session.getAttribute("doador_nome"));
        return "doador/medula/form";
    }

    @PostMapping("/doador/medula/form")
    public String salvarMedula(HttpSession session, RedirectAttributes redirectAttributes) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        redirectAttributes.addFlashAttribute("sucesso", "Doação de medula agendada com sucesso!");
        return "redirect:/doador/home";
    }

    @GetMapping("/doador/leite/form")
    public String formLeite(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        model.addAttribute("doadorNome", session.getAttribute("doador_nome"));
        return "doador/leite/form";
    }

    @PostMapping("/doador/leite/form")
    public String salvarLeite(HttpSession session, RedirectAttributes redirectAttributes) {
        if (session.getAttribute("doador_id") == null) return "redirect:/doador/cadastro";
        redirectAttributes.addFlashAttribute("sucesso", "Doação de leite agendada com sucesso!");
        return "redirect:/doador/home";
    }

    // ── HOME DO DOADOR ──────────────────────────────────────────────

    @GetMapping("/doador/home")
    public String homeDoador(HttpSession session, Model model) {
        if (session.getAttribute("doador_id") == null) {
            return "redirect:/doador/cadastro";
        }
        model.addAttribute("nome",       session.getAttribute("doador_nome"));
        model.addAttribute("tipoDoador", session.getAttribute("tipo_doacao"));
        return "doador/home";
    }

    @GetMapping("/doador/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}