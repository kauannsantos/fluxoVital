package com.fluxo.fluxovitaldoador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FluxovitalDoadorApplicationTests {

    @Test
    void contextLoads() {
    }
}
