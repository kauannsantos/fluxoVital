package com.fluxo.fluxovitaldoador.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    /** 1. Página inicial — index.php → / */
    @GetMapping("/")
    public String index() {
        return "home/index";
    }

    /** 2. Tipos de cadastro — tipos_cadastros.php → /cadastro/tipos */
    @GetMapping("/cadastro/tipos")
    public String tiposCadastros() {
        return "cadastro/tipos_cadastros";
    }

    /** 3. Escolha de categoria (doador) — escolha_categoria.php → /cadastro/doador/categoria */
    @GetMapping("/cadastro/doador/categoria")
    public String escolhaCategoria() {
        return "cadastro/escolha_categoria";
    }

    /** Rota de conveniência: captura tipo de doação na sessão antes de ir para cadastro */
    @GetMapping("/cadastro/doador/selecionar")
    public String selecionarTipo(@RequestParam String tipo, HttpSession session) {
        session.setAttribute("tipo_doacao", tipo);
        return "redirect:/doador/cadastro";
    }
}
