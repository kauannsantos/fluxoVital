package com.fluxo.fluxovitaldoador.repository;

import com.fluxo.fluxovitaldoador.model.Doador;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DoadorRepository extends JpaRepository<Doador, Long> {
    Optional<Doador> findByEmail(String email);
}