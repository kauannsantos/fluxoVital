package com.fluxo.fluxovitaldoador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FluxovitalDoadorApplication {

    public static void main(String[] args) {
        SpringApplication.run(FluxovitalDoadorApplication.class, args);
    }

}
