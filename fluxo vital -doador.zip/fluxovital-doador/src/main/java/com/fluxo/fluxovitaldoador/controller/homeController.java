package com.fluxo.fluxovitaldoador.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class homeController {

    @GetMapping("/")
    @ResponseBody
    public String inicio() {
        return "Projeto funcionando";
    }
}