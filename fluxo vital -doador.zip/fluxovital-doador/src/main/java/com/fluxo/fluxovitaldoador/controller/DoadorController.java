package com.fluxo.fluxovitaldoador.controller;

import com.fluxo.fluxovitaldoador.model.Doador;
import com.fluxo.fluxovitaldoador.repository.DoadorRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.Year;
import java.util.List;
import java.util.Optional;

@Controller
public class DoadorController {

    private final DoadorRepository doadorRepository;
    private final PasswordEncoder passwordEncoder;

    public DoadorController(DoadorRepository doadorRepository, PasswordEncoder passwordEncoder) {
        this.doadorRepository = doadorRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/doador/cadastro")
    public String exibirCadastro(HttpSession session, Model model) {
        if (session.getAttribute("tipo_doacao") == null) {
            session.setAttribute("tipo_doacao", "sangue");
        }

        model.addAttribute("tipoDoacao", session.getAttribute("tipo_doacao"));
        model.addAttribute("anoAtual", Year.now().getValue());
        return "doador/cadastro";
    }

    @PostMapping("/doador/cadastro")
    public String processarCadastro(
            @RequestParam String nome,
            @RequestParam String email,
            @RequestParam String telefone,
            @RequestParam String senha,
            @RequestParam("confirma_senha") String confirmaSenha,
            HttpSession session,
            RedirectAttributes redirectAttributes
    ) {
        String tipoDoador = (String) session.getAttribute("tipo_doacao");
        List<String> tiposValidos = List.of("sangue", "medula", "leite");

        if (tipoDoador == null || !tiposValidos.contains(tipoDoador)) {
            redirectAttributes.addFlashAttribute("erro", "Tipo de doação inválido.");
            return "redirect:/doador/cadastro";
        }

        if (nome.isBlank() || email.isBlank() || telefone.isBlank() || senha.isBlank() || confirmaSenha.isBlank()) {
            redirectAttributes.addFlashAttribute("erro", "Preencha todos os campos corretamente.");
            return "redirect:/doador/cadastro";
        }

        if (!senha.equals(confirmaSenha)) {
            redirectAttributes.addFlashAttribute("erro", "As senhas não coincidem.");
            return "redirect:/doador/cadastro";
        }

        Optional<Doador> doadorExistente = doadorRepository.findByEmail(email);

        if (doadorExistente.isPresent()) {
            Doador doador = doadorExistente.get();

            if (passwordEncoder.matches(senha, doador.getSenha())) {
                session.setAttribute("doador_id", doador.getId());
                session.setAttribute("doador_nome", doador.getNome());
                return "redirect:/";
            } else {
                redirectAttributes.addFlashAttribute("erro", "Este e-mail já está cadastrado, mas a senha está incorreta.");
                return "redirect:/doador/cadastro";
            }
        }

        Doador novoDoador = new Doador();
        novoDoador.setNome(nome.trim());
        novoDoador.setEmail(email.trim());
        novoDoador.setTelefone(telefone.trim());
        novoDoador.setSenha(passwordEncoder.encode(senha));
        novoDoador.setTipoDoador(tipoDoador);

        doadorRepository.save(novoDoador);

        session.setAttribute("doador_id", novoDoador.getId());
        session.setAttribute("doador_nome", novoDoador.getNome());

        return switch (tipoDoador) {
            case "sangue" -> "redirect:/doador/sangue/form";
            case "medula" -> "redirect:/doador/medula/form";
            case "leite" -> "redirect:/doador/leite/form";
            default -> "redirect:/";
        };
    }
}